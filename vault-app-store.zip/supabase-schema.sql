-- ==========================================================
-- SCHEMA DO BANCO DE DADOS — rode isso no SQL Editor do Supabase
-- (Project > SQL Editor > New query > cole tudo > Run)
-- ==========================================================

-- Perfis de usuário (estende a tabela auth.users do Supabase)
create table profiles (
  id uuid references auth.users on delete cascade primary key,
  email text not null,
  name text not null,
  is_admin boolean default false,
  created_at timestamptz default now()
);

-- Cria o perfil automaticamente quando alguém se cadastra
create function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, name, is_admin)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)),
    -- SEU E-MAIL FIXO COMO ADMIN:
    new.email = 'simqwerty4002@gmail.com'
  );
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Apps cadastrados
create table apps (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  developer text,
  description text,
  genres text[] default '{}',
  icon_url text,
  screenshots text[] default '{}',
  download_url text,
  file_path text, -- caminho do APK dentro do bucket 'app-files' (upload direto, sem link externo)
  version text,
  size_mb numeric,
  download_count integer default 0,
  created_at timestamptz default now(),
  created_by uuid references profiles(id)
);

-- Reviews dos usuários
create table reviews (
  id uuid default gen_random_uuid() primary key,
  app_id uuid references apps(id) on delete cascade not null,
  user_id uuid references profiles(id) on delete cascade not null,
  rating integer not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz default now(),
  unique(app_id, user_id) -- um usuário só pode avaliar uma vez por app
);

-- Histórico de downloads (usado pra estatísticas e recomendação)
create table downloads (
  id uuid default gen_random_uuid() primary key,
  app_id uuid references apps(id) on delete cascade not null,
  user_id uuid references profiles(id) on delete cascade not null,
  created_at timestamptz default now()
);

-- View com nota média calculada por app
create view app_ratings as
select
  app_id,
  round(avg(rating)::numeric, 1) as avg_rating,
  count(*) as review_count
from reviews
group by app_id;

-- ==========================================================
-- SEGURANÇA (Row Level Security) — protege os dados
-- ==========================================================

alter table profiles enable row level security;
alter table apps enable row level security;
alter table reviews enable row level security;
alter table downloads enable row level security;

-- Perfis: qualquer um autenticado pode ler; só o dono edita o próprio
create policy "Perfis são públicos para leitura" on profiles for select using (true);
create policy "Usuário edita seu próprio perfil" on profiles for update using (auth.uid() = id);

-- Apps: todo mundo pode ver (mesmo sem login); só admin cria/edita/apaga
create policy "Apps são públicos para leitura" on apps for select using (true);
create policy "Só admin insere apps" on apps for insert with check (
  exists (select 1 from profiles where id = auth.uid() and is_admin = true)
);
create policy "Só admin edita apps" on apps for update using (
  exists (select 1 from profiles where id = auth.uid() and is_admin = true)
);
create policy "Só admin apaga apps" on apps for delete using (
  exists (select 1 from profiles where id = auth.uid() and is_admin = true)
);

-- Reviews: público lê; só usuário logado cria a própria; só o dono edita/apaga a sua
create policy "Reviews são públicas para leitura" on reviews for select using (true);
create policy "Usuário logado cria review" on reviews for insert with check (auth.uid() = user_id);
create policy "Usuário edita a própria review" on reviews for update using (auth.uid() = user_id);
create policy "Usuário apaga a própria review" on reviews for delete using (auth.uid() = user_id);

-- Downloads: usuário só vê os próprios; qualquer logado pode registrar um download seu
create policy "Usuário vê os próprios downloads" on downloads for select using (auth.uid() = user_id);
create policy "Usuário logado registra download" on downloads for insert with check (auth.uid() = user_id);

-- ==========================================================
-- FUNÇÃO: incrementa contador de downloads do app (chamada via RPC)
-- ==========================================================
create function increment_download_count(app_id_input uuid)
returns void as $$
begin
  update apps set download_count = download_count + 1 where id = app_id_input;
end;
$$ language plpgsql security definer;

-- ==========================================================
-- STORAGE — bucket para hospedar os APKs dentro do próprio projeto
-- Assim o botão "Baixar" baixa o arquivo direto do seu site,
-- sem abrir link nem aba de outro serviço.
-- Plano free do Supabase inclui 1GB de storage.
-- ==========================================================

insert into storage.buckets (id, name, public)
values ('app-files', 'app-files', true)
on conflict (id) do nothing;

-- Qualquer um pode baixar (bucket público para leitura)
create policy "Arquivos de apps são públicos para leitura"
on storage.objects for select
using (bucket_id = 'app-files');

-- Só admin pode enviar arquivos
create policy "Só admin envia arquivos de apps"
on storage.objects for insert
with check (
  bucket_id = 'app-files'
  and exists (select 1 from profiles where id = auth.uid() and is_admin = true)
);

-- Só admin pode apagar arquivos
create policy "Só admin apaga arquivos de apps"
on storage.objects for delete
using (
  bucket_id = 'app-files'
  and exists (select 1 from profiles where id = auth.uid() and is_admin = true)
);
