# Vault — loja de apps grátis

Site de catálogo de apps com login, downloads reais, avaliações e um painel admin
que busca dados de apps direto da Play Store. Feito para rodar com **Supabase**
(banco de dados + login) e **Netlify** (hospedagem + funções de backend).

## O que já vem pronto

- Busca de apps ao vivo
- Ranking "mais baixados" calculado pelo número real de downloads
- "Chegou agora" com os apps mais recentes
- Cadastro/login obrigatório só na hora de baixar (navegação livre antes disso)
- Página de cada app com screenshots, nota média e reviews de usuários
- Painel admin (só para o seu e-mail) que busca automaticamente nome, ícone,
  descrição, gêneros e capturas de tela de um app pesquisando na Play Store
- Recomendações personalizadas usando a API da Anthropic (Claude), baseadas
  no histórico de downloads de cada pessoa

---

## Passo 1 — Criar o projeto no Supabase

1. Crie uma conta em [supabase.com](https://supabase.com) e clique em "New project".
2. Espere o projeto terminar de provisionar (leva ~2 min).
3. Vá em **SQL Editor** (menu lateral) → **New query**.
4. Abra o arquivo `supabase-schema.sql` deste projeto, copie tudo, cole no editor e clique em **Run**.
   - Isso cria as tabelas (`apps`, `reviews`, `downloads`, `profiles`), as regras de segurança,
     e já marca `simqwerty4002@gmail.com` como admin automaticamente quando essa conta for criada.
5. Vá em **Settings > API**. Você vai precisar de dois valores:
   - **Project URL** → vai virar `VITE_SUPABASE_URL`
   - **anon public key** → vai virar `VITE_SUPABASE_ANON_KEY`
6. Ainda em **Settings > API**, copie também a **service_role key** (fica escondida, clique para revelar).
   - **Essa chave é secreta.** Nunca coloque ela no código do frontend — só vai para as
     variáveis de ambiente do Netlify (usada pela função de recomendação).
   - Vira `SUPABASE_SERVICE_ROLE_KEY`.

### Confirmação de e-mail (recomendado desativar no começo)

Por padrão o Supabase exige confirmar o e-mail antes de logar. Para testar mais rápido:
vá em **Authentication > Providers > Email** e desative "Confirm email" enquanto testa.
Reative depois se quiser mais segurança em produção.

---

## Passo 2 — Pegar a chave da Anthropic (para as recomendações com IA)

1. Entre em [console.anthropic.com](https://console.anthropic.com/settings/keys)
2. Crie uma chave de API.
3. Isso vira `ANTHROPIC_API_KEY`. Essa chave é paga por uso (não tem plano grátis
   ilimitado) — cada recomendação gerada consome uma fração de centavo. Você pode
   acompanhar o consumo no console da Anthropic e definir um limite de gasto mensal.

---

## Passo 3 — Testar localmente (opcional, mas recomendado antes do deploy)

```bash
npm install
cp .env.example .env
```

Abra o `.env` e preencha com os valores reais do Supabase. Depois:

```bash
npm run dev
```

Isso sobe o site em `http://localhost:5173`. As Netlify Functions (busca na Play Store
e recomendação) só funcionam de verdade depois do deploy no Netlify — localmente elas
vão dar erro 404, o que é esperado.

---

## Passo 4 — Deploy no Netlify

1. Suba este projeto para um repositório no GitHub.
2. Em [app.netlify.com](https://app.netlify.com), clique em **Add new site > Import an existing project**.
3. Conecte com o GitHub e escolha o repositório.
4. O Netlify já vai detectar `npm run build` e a pasta `dist` (configurado no `netlify.toml`) — não precisa mudar nada aí.
5. Antes de clicar em "Deploy", vá em **Environment variables** e adicione:

| Nome | Valor |
|---|---|
| `VITE_SUPABASE_URL` | a Project URL do Supabase |
| `VITE_SUPABASE_ANON_KEY` | a anon public key do Supabase |
| `SUPABASE_SERVICE_ROLE_KEY` | a service_role key do Supabase (secreta) |
| `ANTHROPIC_API_KEY` | sua chave da Anthropic |

6. Clique em **Deploy site**.

Depois de qualquer mudança nessas variáveis, é preciso rodar um novo deploy
(**Deploys > Trigger deploy > Clear cache and deploy site**) para elas terem efeito.

---

## Passo 5 — Virar admin

1. No site já publicado, clique em **Criar conta** e cadastre-se usando
   exatamente `simqwerty4002@gmail.com`.
2. Assim que essa conta for criada, o gatilho do banco marca ela como admin automaticamente.
3. Depois de logado, um botão **Admin** aparece na barra do topo.

---

## Como cadastrar um app de verdade

1. Vá em **Admin** (só aparece logado como admin).
2. Digite o nome exato do app (ex: "Duolingo") e clique em **Buscar**.
3. O site busca na Play Store e mostra nome, ícone, descrição, gêneros e capturas de tela.
4. Revise as informações. Se algo vier errado, pode buscar de novo com um termo mais específico.
5. Cole o **link direto de download** do arquivo (ex: um link compartilhável do Google
   Drive, um link de "Releases" no GitHub, ou qualquer link direto de arquivo).
6. Clique em **Publicar app**.

O contador de downloads sobe de verdade a cada clique em "Baixar" por um usuário logado,
e isso alimenta o ranking "Mais baixados" automaticamente.

---

## Sobre a busca na Play Store

A busca usa a biblioteca gratuita `google-play-scraper`, que lê páginas públicas da
Play Store sem precisar de chave de API paga. Não tem limite de uso e é gratuita para
sempre — mas por não ser uma API oficial, pode ocasionalmente falhar ou parar de
funcionar se o Google mudar a estrutura do site (nesses casos, normalmente uma
atualização da biblioteca resolve, ou dá para cadastrar o app manualmente enquanto isso).

## Sobre a recomendação com IA

Usa a API da Anthropic para comparar o histórico de downloads do usuário com o catálogo
disponível e sugerir até 4 apps parecidos, com uma frase explicando o motivo. Se a API
falhar por qualquer motivo, o site cai automaticamente para uma recomendação simples por
gênero em comum, então a home nunca quebra por causa disso.
